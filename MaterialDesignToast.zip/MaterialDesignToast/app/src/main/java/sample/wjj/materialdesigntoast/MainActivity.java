package sample.wjj.materialdesigntoast;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import sample.wjj.materialdesigntoast.views.ButtonFlat;
import sample.wjj.materialdesigntoast.widgets.SnackBar;

public class MainActivity extends AppCompatActivity {
    ButtonFlat button,button1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = (ButtonFlat) findViewById(R.id.button);
        button1=(ButtonFlat)findViewById(R.id.button1);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SnackBar snackbar = new SnackBar(MainActivity.this, "这是一段很长的文字", "按钮的文字内容",
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Toast.makeText(MainActivity.this, "按钮被点击后吐出的内容", Toast.LENGTH_SHORT).show();
                            }
                        });
                snackbar.setDismissTimer(9000);
                snackbar.show();
            }
        });

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SnackBar snackBar=new SnackBar(MainActivity.this,"只有文字");
                snackBar.setBackgroundSnackBar(getResources().getColor(R.color.BrulyWood));
                snackBar.setMessageTextSize(20);
                snackBar.show();
            }
        });

    }

}
