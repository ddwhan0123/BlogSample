package ezreal.sample.wjj.viewanimdemo.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;

import com.apkfuns.logutils.LogUtils;

import java.util.ArrayList;
import java.util.List;

import ezreal.sample.wjj.viewanimdemo.R;

public class MainActivity extends AppCompatActivity {
    private ImageView imageView;
    private ListView listView;
    private ArrayList<String> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        LogUtils.d("--->MainActivity onCreate");

        imageView = (ImageView) findViewById(R.id.imageView);
        listView = (ListView) findViewById(R.id.listView);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_expandable_list_item_1, getData());
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                makeAnim(position);
            }
        });
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        LogUtils.d("--->MainActivity onRestart");
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        LogUtils.d("--->MainActivity onWindowFocusChanged");
    }

    @Override
    protected void onPause() {
        super.onPause();
        LogUtils.d("--->MainActivity onPause");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LogUtils.d("--->MainActivity onDestroy");
    }

    private List<String> getData() {
        list.add("平移效果");
        list.add("根据左上角旋转效果");
        list.add("放大效果");
        list.add("渐渐消失");
        list.add("5");
        list.add("6");
        list.add("7");
        list.add("8");
        list.add("9");
        list.add("10");
        list.add("11");
        return list;
    }

    //演示动画效果
    //注释掉的部分和现有实现统一效果
    private void makeAnim(int pos) {
        Animation animation;
//        TranslateAnimation translateAnimation;
//        RotateAnimation rotateAnimation;
        ScaleAnimation scaleAnimation;
        AlphaAnimation alphaAnimation;
        switch (pos) {
            case 0://平移效果
                LogUtils.d("--->makeAnim 0 平移效果");
//              translateAnimation = new TranslateAnimation(0, 200, 0, 50);
//              translateAnimation.setDuration(2000);
//              imageView.startAnimation(translateAnimation);
                animation = AnimationUtils.loadAnimation(this, R.anim.anim_test1);
                animation.setDuration(2000);
                imageView.startAnimation(animation);
                break;
            case 1:
                LogUtils.d("--->makeAnim 1 旋转效果");
//                rotateAnimation = new RotateAnimation(0, 90);
//                rotateAnimation.setDuration(2000);
//                imageView.startAnimation(rotateAnimation);
                animation = AnimationUtils.loadAnimation(this, R.anim.anim_test2);
                animation.setDuration(2000);
                imageView.startAnimation(animation);
                break;
            case 2:
                LogUtils.d("--->makeAnim 2 放大效果");
//                scaleAnimation = new ScaleAnimation(0, 2, 0, 2);
//                scaleAnimation.setDuration(2000);
//                imageView.startAnimation(scaleAnimation);
                animation = AnimationUtils.loadAnimation(this, R.anim.anim_test3);
                imageView.startAnimation(animation);
                break;
            case 3:
                LogUtils.d("--->makeAnim 3 渐渐消失效果");
//                alphaAnimation = new AlphaAnimation(1.0f, 0.2f);
//                alphaAnimation.setDuration(2000);
//                imageView.startAnimation(alphaAnimation);
                animation = AnimationUtils.loadAnimation(this, R.anim.anim_test4);
                imageView.startAnimation(animation);
                break;
        }
    }
}
