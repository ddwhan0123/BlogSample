package ezreal.sample.wjj.viewanimdemo.Activity;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.graphics.Interpolator;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;

import com.apkfuns.logutils.LogUtils;

import java.util.ArrayList;
import java.util.List;

import ezreal.sample.wjj.viewanimdemo.R;

public class MainActivity extends AppCompatActivity {
    private ImageView imageView;
    private ListView listView;
    private ArrayList<String> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        LogUtils.d("--->MainActivity onCreate");

        imageView = (ImageView) findViewById(R.id.imageView);
        listView = (ListView) findViewById(R.id.listView);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_expandable_list_item_1, getData());
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                makeAnim(position);
            }
        });
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        LogUtils.d("--->MainActivity onRestart");
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        LogUtils.d("--->MainActivity onWindowFocusChanged");
    }

    @Override
    protected void onPause() {
        super.onPause();
        LogUtils.d("--->MainActivity onPause");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LogUtils.d("--->MainActivity onDestroy");
    }

    private List<String> getData() {
        list.add("平移效果");
        list.add("根据左上角旋转效果");
        list.add("放大效果");
        list.add("渐渐消失");
        list.add("沿着X轴旋转");
        list.add("沿着Y轴旋转");
        list.add("沿着x轴放大");
        list.add("沿着y轴放大");
        list.add("沿着x轴平移");
        list.add("沿着Y轴平移");
        list.add("沿着y轴X轴平移 过程中旋转");
        list.add("先放大,放大的过程中旋转,旋转完再渐消失");
        list.add("放大,旋转,渐消失");
        list.add("ValueAnimator 执行x平移并回到原位");
        list.add(" ValueAnimator 执行放大并回到原来的样子");
        return list;
    }

    //演示动画效果
    //注释掉的部分和现有实现统一效果
    private void makeAnim(int pos) {
        Animation animation;
//        TranslateAnimation translateAnimation;
//        RotateAnimation rotateAnimation;
//        ScaleAnimation scaleAnimation;
//        AlphaAnimation alphaAnimation;
        switch (pos) {
            case 0://平移效果
                LogUtils.d("--->makeAnim 0 平移效果");
//              translateAnimation = new TranslateAnimation(0, 200, 0, 50);
//              translateAnimation.setDuration(2000);
//              imageView.startAnimation(translateAnimation);
                animation = AnimationUtils.loadAnimation(this, R.anim.anim_test1);
                animation.setDuration(2000);
                imageView.startAnimation(animation);
                break;
            case 1:
                LogUtils.d("--->makeAnim 1 旋转效果");
//                rotateAnimation = new RotateAnimation(0, 90);
//                rotateAnimation.setDuration(2000);
//                imageView.startAnimation(rotateAnimation);
                animation = AnimationUtils.loadAnimation(this, R.anim.anim_test2);
                animation.setDuration(2000);
                imageView.startAnimation(animation);
                break;
            case 2:
                LogUtils.d("--->makeAnim 2 放大效果");
//                scaleAnimation = new ScaleAnimation(0, 2, 0, 2);
//                scaleAnimation.setDuration(2000);
//                imageView.startAnimation(scaleAnimation);
                animation = AnimationUtils.loadAnimation(this, R.anim.anim_test3);
                imageView.startAnimation(animation);
                break;
            case 3:
                LogUtils.d("--->makeAnim 3 渐渐消失效果");
//                alphaAnimation = new AlphaAnimation(1.0f, 0.2f);
//                alphaAnimation.setDuration(2000);
//                imageView.startAnimation(alphaAnimation);
                animation = AnimationUtils.loadAnimation(this, R.anim.anim_test4);
                imageView.startAnimation(animation);
                break;
            case 4:
                LogUtils.d("--->makeAnim 4 ObjectAnimator 沿着x轴旋转");
                ObjectAnimator.ofFloat(imageView, "rotationX", 0.0f, 360.0f)
                        .setDuration(2000).start();
                break;
            case 5:
                LogUtils.d("--->makeAnim 5 ObjectAnimator 沿着y轴旋转");
                ObjectAnimator.ofFloat(imageView, "rotationY", 0.0f, 150.0f, 0.0f).setDuration(2000).start();
                break;
            case 6:
                LogUtils.d("--->makeAnim 6 ObjectAnimator 沿着x轴放大");
                ObjectAnimator.ofFloat(imageView, "scaleX", 1.0f, 1.5f, 1.0f).setDuration(2000).start();
                break;
            case 7:
                LogUtils.d("--->makeAnim 7 ObjectAnimator 沿着y轴放大");
                ObjectAnimator.ofFloat(imageView, "scaleY", 1.0f, 1.5f, 1.0f).setDuration(2000).start();
                break;
            case 8:
                LogUtils.d("--->makeAnim 8 ObjectAnimator 沿着X轴平移");
                ObjectAnimator.ofFloat(imageView, "translationX", 0.0f, 200.0f, 0.0f).setDuration(2000).start();
                break;
            case 9:
                LogUtils.d("--->makeAnim 9 ObjectAnimator 沿着y轴平移 执行2次");
                ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(imageView, "translationY", 0.0f, 200.0f, 0.0f);
                objectAnimator.setDuration(2000);
                objectAnimator.setRepeatCount(2);//重复次数
                objectAnimator.setRepeatMode(ValueAnimator.RESTART);//重复模式
                objectAnimator.start();
                break;
            case 10:
                LogUtils.d("--->makeAnim 10 ObjectAnimator 沿着y轴X轴平移 过程中旋转");
                ObjectAnimator objectAnimator1 = ObjectAnimator.ofFloat(imageView, "translationY", 0.0f, 250.0f, 0.0f);
                ObjectAnimator objectAnimator2 = ObjectAnimator.ofFloat(imageView, "translationX", 0.0f, 250.0f, 0.0f);
                ObjectAnimator objectAnimator3 = ObjectAnimator.ofFloat(imageView, "rotationY", 0.0f, 360.0f);
                AnimatorSet animationSet = new AnimatorSet();//组合动画
                animationSet.play(objectAnimator1).with(objectAnimator2).with(objectAnimator3);
                animationSet.setDuration(4000);
                animationSet.setStartDelay(1500);
                animationSet.start();
                break;
            case 11:
                LogUtils.d("--->makeAnim 11 ObjectAnimator 先放大,放大的过程中旋转,再渐消失");
                ObjectAnimator objectAnimator4 = ObjectAnimator.ofFloat(imageView, "scaleX", 1.0f, 2.0f, 1.0f);
                ObjectAnimator objectAnimator5 = ObjectAnimator.ofFloat(imageView, "scaleY", 1.0f, 2.0f, 1.0f);
                ObjectAnimator objectAnimator6 = ObjectAnimator.ofFloat(imageView, "alpha", 1.0f, 0.2f, 1.0f);
                ObjectAnimator objectAnimator7 = ObjectAnimator.ofFloat(imageView, "rotationX", 0.0f, 360.0f);
                AnimatorSet animationSet1 = new AnimatorSet();//组合动画
                animationSet1.setDuration(4000);
                animationSet1.play(objectAnimator4).with(objectAnimator5).with(objectAnimator7).before(objectAnimator6);
                animationSet1.start();
                break;
            case 12:
                LogUtils.d("--->makeAnim 12 ObjectAnimator 放大,旋转,渐消失");
                PropertyValuesHolder valuesHolder = PropertyValuesHolder.ofFloat("scaleX", 1.0f, 2.0f, 1.0f);
                PropertyValuesHolder valuesHolder1 = PropertyValuesHolder.ofFloat("scaleY", 1.0f, 2.0f, 1.0f);
                PropertyValuesHolder valuesHolder2 = PropertyValuesHolder.ofFloat("alpha", 1.0f, 0.2f, 1.0f);
                PropertyValuesHolder valuesHolder3 = PropertyValuesHolder.ofFloat("rotationY", 0.0f, 360.0f);
                ObjectAnimator objectAnimator8 = ObjectAnimator.ofPropertyValuesHolder(imageView, valuesHolder, valuesHolder1, valuesHolder2, valuesHolder3);
                objectAnimator8.setDuration(4000);
                objectAnimator8.start();
                break;
            case 13:
                LogUtils.d("--->makeAnim 13 ValueAnimator 执行x平移并回到原位");
                makeValueAnimatorTranslationX();
                break;
            case 14:
                LogUtils.d("--->makeAnim 14 ValueAnimator 执行放大并回到原来的样子");
                makeValueAnimatorScale();
                break;
        }
    }

    private void makeValueAnimatorTranslationX() {
        //创建ValueAnimator对象,并初始化
        ValueAnimator valueAnimator = ValueAnimator.ofInt(0, 200, 0);
        valueAnimator.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {
                LogUtils.d("--->onAnimationStart");
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                LogUtils.d("--->onAnimationEnd");
            }

            @Override
            public void onAnimationCancel(Animator animation) {
                LogUtils.d("--->onAnimationCancel");
            }

            @Override
            public void onAnimationRepeat(Animator animation) {
                LogUtils.d("--->onAnimationRepeat");
            }
        });
        //属性变化大监听器
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                int animationorValue = (Integer) animation.getAnimatedValue();
                LogUtils.d("--->当前进度值: " + animationorValue);
                imageView.setTranslationX(animationorValue);
            }
        });
        valueAnimator.setDuration(2000);
        valueAnimator.setRepeatCount(4);
        valueAnimator.setRepeatMode(ValueAnimator.RESTART);
        //绑定需要执行动画的对象
        valueAnimator.setTarget(imageView);
        valueAnimator.start();
    }

    private void makeValueAnimatorScale() {
        PropertyValuesHolder propertyValuesHolder1 = PropertyValuesHolder.ofFloat("scaleX", 1.0f, 2.0f, 1.0f);
        PropertyValuesHolder propertyValuesHolder2 = PropertyValuesHolder.ofFloat("scaleY", 1.0f, 2.0f, 1.0f);
        ValueAnimator valueAnimator=ValueAnimator.ofPropertyValuesHolder(propertyValuesHolder1,propertyValuesHolder2);
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                float xValue=(float)animation.getAnimatedValue("scaleX");
                float YValue=(float)animation.getAnimatedValue("scaleY");
                imageView.setScaleX(xValue);
                imageView.setScaleY(YValue);
            }
        });
        valueAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
        valueAnimator.setDuration(2000);
        valueAnimator.setRepeatCount(2);
        valueAnimator.setRepeatMode(Animation.RESTART);
        valueAnimator.setTarget(imageView);
        valueAnimator.start();
    }

}
