package sample.wjj.materialdesignedittext.custom.validation;


public abstract class METLengthChecker {

    public abstract int getLength(CharSequence text);

}
