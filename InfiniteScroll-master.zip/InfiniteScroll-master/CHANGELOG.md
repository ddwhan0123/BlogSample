v. 0.0.1
--------
*20 Feb 2016*

- first release of the library
