package sample.wjj.glidedemo;

import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomSheetBehavior;
import android.support.v4.view.ViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.github.pwittchen.infinitescroll.library.InfiniteScrollListener;

import java.util.LinkedList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final int MAX_ITEMS_PER_REQUEST = 20;
    private static final int NUMBER_OF_ITEMS = 100;
    private static final int SIMULATED_LOADING_TIME_IN_MS = 1500;

    private ImageView imageView;
    public Toolbar toolbar;
    public RecyclerView recyclerView;
    public ProgressBar progressBar;

    private MyAdapter myAdapter;
    private LinearLayoutManager layoutManager;
    private List<String> items;
    private int page = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.items = createItems();
        initViews();
        initRecyclerView();
        setSupportActionBar(toolbar);
    }

    private List<String> createItems() {
        List<String> items = new LinkedList<>();
        for (int i = 0; i < NUMBER_OF_ITEMS; i++) {
            String prefix = i < 10 ? "0" : "";
            items.add("Item #".concat(prefix).concat(String.valueOf(i)));
        }
        return items;
    }

    private void initViews() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        progressBar = (ProgressBar) findViewById(R.id.progress_bar);
        imageView = (ImageView) findViewById(R.id.imageView);
        Glide.with(this).load(Config.IMAGE_URL).into(imageView);


    }

    private void initRecyclerView() {
        layoutManager = new LinearLayoutManager(this);
        //如果item高度不变,提升性能操作
        recyclerView.setHasFixedSize(true);
        //设置ListView样式
        recyclerView.setLayoutManager(layoutManager);
        //添加适配器,subList方法截取了原本100长度的ArrayList的0->MAX_ITEMS_PER_REQUEST 部分
        myAdapter = new MyAdapter(items.subList(page, MAX_ITEMS_PER_REQUEST), MainActivity.this);
        recyclerView.setAdapter(myAdapter);
        //添加滑动监听
        recyclerView.addOnScrollListener(createInfiniteScrollListener());

        myAdapter.setOnItemClickListener(new MyAdapter.OnRecyclerViewItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Toast.makeText(MainActivity.this, "第" + position + "被点击", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @NonNull
    private InfiniteScrollListener createInfiniteScrollListener() {
        return new InfiniteScrollListener(MAX_ITEMS_PER_REQUEST, layoutManager) {
            @Override
            public void onScrolledToEnd(final int firstVisibleItemPosition) {
                Log.d("-->firstVisible", "firstVisibleItemPosition : " + firstVisibleItemPosition);
                simulateLoading();
                //每次加载X * 20个item
                int start = ++page * MAX_ITEMS_PER_REQUEST;
                final boolean allItemsLoaded = start >= items.size();
                if (allItemsLoaded) {
                    progressBar.setVisibility(View.GONE);
                } else {
                    int end = start + MAX_ITEMS_PER_REQUEST;
                    //合成新的数据源
                    final List<String> items = getItemsToBeLoaded(start, end);
                    //重新刷新View
                    refreshView(recyclerView, new MyAdapter(items, MainActivity.this), firstVisibleItemPosition);
                }
            }
        };
    }

    @NonNull
    private List<String> getItemsToBeLoaded(int start, int end) {
        List<String> newItems = items.subList(start, end);
        final List<String> oldItems = ((MyAdapter) recyclerView.getAdapter()).getItems();
        final List<String> items = new LinkedList<>();
        items.addAll(oldItems);
        items.addAll(newItems);
        return items;
    }

    /**
     * WARNING! This method is only for demo purposes!
     * Don't do anything like that in your regular project!
     */
    private void simulateLoading() {
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected void onPreExecute() {
                progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            protected Void doInBackground(Void... params) {
                try {
                    Thread.sleep(SIMULATED_LOADING_TIME_IN_MS);
                } catch (InterruptedException e) {
                    Log.e("MainActivity", e.getMessage());
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void param) {
                progressBar.setVisibility(View.GONE);
            }
        }.execute();
    }
}
