package sample.wjj.glidedemo;

/**
 * Created by jiajiewang on 16/3/23.
 */
public class Config {
    public static final String IMAGE_URL = "http://img4.imgtn.bdimg.com/it/u=3176138886,1651839182&fm=21&gp=0.jpg";
    public static final String IMAGE_ITEM_URL = "http://img4.imgtn.bdimg.com/it/u=2768235495,2154602075&fm=21&gp=0.jpg";
}
