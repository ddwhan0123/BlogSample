package com.wjj.numberdemo.listener;

import android.os.Message;

/**
 * Created by jiajiewang on 16/9/2.
 */
public interface CommunicateListener {
    void setMsg(Message msg);
}
