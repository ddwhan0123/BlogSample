package sample.wjj.recyclerviewmanagerdemo.manager;


public enum RecyclerMode {

    NONE, BOTH, TOP, BOTTOM

}
