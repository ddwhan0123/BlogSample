package sample.wjj.recyclerviewmanagerdemo;

import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import sample.wjj.recyclerviewmanagerdemo.adapter.RefreshRecyclerViewAdapter;
import sample.wjj.recyclerviewmanagerdemo.listener.OnBothRefreshListener;
import sample.wjj.recyclerviewmanagerdemo.manager.RecyclerMode;
import sample.wjj.recyclerviewmanagerdemo.manager.RecyclerViewManager;
import sample.wjj.recyclerviewmanagerdemo.view.RefreshRecyclerView;

public class MainActivity extends AppCompatActivity {
    //仿造的数据源
    private ArrayList<String> mDatas;
    private static final int PULL_DOWN = 1;
    private static final int LOAD_MORE = 2;
    private int counts = 10;
    private DataAdapter dataAdapter;
    private int page = 1;
    private RefreshRecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //填充数据
        makeData();

        View header = View.inflate(this, R.layout.recycler_header, null);

        recyclerView = (RefreshRecyclerView) findViewById(R.id.recyclerView);
        dataAdapter = new DataAdapter();

        RecyclerViewManager.with(dataAdapter, new LinearLayoutManager(this))
                .setMode(RecyclerMode.BOTH)
                .addHeaderView(header)//可以不只一个header
//                .addHeaderView(header)
                .addFooterView(header)
                .setOnBothRefreshListener(new OnBothRefreshListener() {
                    @Override
                    public void onPullDown() {
                        //模拟网络请求
                        Message msg = new Message();
                        msg.what = PULL_DOWN;
                        mHandler.sendMessageDelayed(msg, 2000);
                    }

                    @Override
                    public void onLoadMore() {
                        //模拟网络请求
                        if (page > 5) {
                            //模拟共有5页数据
                            Toast.makeText(MainActivity.this, "No more datas!", Toast.LENGTH_SHORT).show();
                            recyclerView.onRefreshCompleted();
                            return;
                        }
                        page++;
                        Message msg = new Message();
                        msg.what = LOAD_MORE;
                        mHandler.sendMessageDelayed(msg, 2000);
                    }
                })
//                .setOnPullDownListener(new OnPullDownListener() {
//                    @Override
//                    public void onPullDown() {
//                        Message msg = new Message();
//                        msg.what = PULL_DOWN;
//                        mHandler.sendMessageDelayed(msg, 2000);
//                    }
//                })
//                .setOnLoadMoreListener(new OnLoadMoreListener() {
//                    @Override
//                    public void onLoadMore() {
//                        //模拟网络请求
//                        if (page > 5) {
//                            //模拟共有5页数据
//                            Toast.makeText(MainActivity.this, "No more datas!", Toast.LENGTH_SHORT).show();
//                            recyclerView.onRefreshCompleted();
//                            return;
//                        }
//                        page++;
//                        Message msg = new Message();
//                        msg.what = LOAD_MORE;
//                        mHandler.sendMessageDelayed(msg, 2000);
//                    }
//                })
                .setOnItemClickListener(new RefreshRecyclerViewAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(RecyclerView.ViewHolder holder, int position) {
                        Toast.makeText(MainActivity.this, "item" + position, Toast.LENGTH_SHORT).show();
                    }
                })
                .into(recyclerView, this);


    }

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case PULL_DOWN:
                    mDatas.add("下拉刷新出来的 第 " + counts + "个");
                    break;
                case LOAD_MORE:
                    for (int i = 0; i < 5; i++) {
                        mDatas.add("上啦刷新出来的  第" + (counts + i));
                    }
                    counts += 5;
                    break;
            }
            recyclerView.onRefreshCompleted();
            dataAdapter.notifyDataSetChanged();
        }
    };

    class DataViewHolder extends RecyclerView.ViewHolder {

        public TextView tv_item;

        public DataViewHolder(View itemView) {

            super(itemView);
            tv_item = (TextView) itemView.findViewById(R.id.tv_item);

        }

    }

    class DataAdapter extends RecyclerView.Adapter<DataViewHolder> {

        @Override
        public DataViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(MainActivity.this).
                    inflate(R.layout.recycler_item, parent, false);
            DataViewHolder holder = new DataViewHolder(v);
            return holder;
        }

        @Override
        public void onBindViewHolder(DataViewHolder holder, int position) {
            holder.tv_item.setText(mDatas.get(position));
        }

        @Override
        public int getItemCount() {
            return mDatas.size();
        }
    }

    private void makeData() {

        mDatas = new ArrayList<>();
        for (int k = 0; k < 10; k++) {

            mDatas.add("第" + k + "个");

        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        switch (id){
            case R.id.action_linear:
                RecyclerViewManager.setLayoutManager(new LinearLayoutManager(this));
                break;
            case R.id.action_grid:
                RecyclerViewManager.setLayoutManager(new GridLayoutManager(this, 3));
                break;
            case R.id.action_staggered:
                RecyclerViewManager.setLayoutManager(new StaggeredGridLayoutManager(
                        2, StaggeredGridLayoutManager.VERTICAL));
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

}
