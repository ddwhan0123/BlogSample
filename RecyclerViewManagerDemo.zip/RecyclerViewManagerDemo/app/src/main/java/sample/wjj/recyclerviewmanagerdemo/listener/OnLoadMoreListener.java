package sample.wjj.recyclerviewmanagerdemo.listener;


public interface OnLoadMoreListener {

    void onLoadMore();
}
