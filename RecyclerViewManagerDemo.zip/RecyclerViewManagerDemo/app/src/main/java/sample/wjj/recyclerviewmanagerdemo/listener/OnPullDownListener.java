package sample.wjj.recyclerviewmanagerdemo.listener;


public interface OnPullDownListener {

    void onPullDown();

}
