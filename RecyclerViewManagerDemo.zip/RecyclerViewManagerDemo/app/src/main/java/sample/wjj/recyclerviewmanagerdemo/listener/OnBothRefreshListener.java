package sample.wjj.recyclerviewmanagerdemo.listener;


public interface OnBothRefreshListener {

    void onPullDown();

    void onLoadMore();
}
