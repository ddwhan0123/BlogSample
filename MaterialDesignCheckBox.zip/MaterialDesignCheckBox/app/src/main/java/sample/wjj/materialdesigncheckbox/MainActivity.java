package sample.wjj.materialdesigncheckbox;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import sample.wjj.materialdesigncheckbox.views.CheckBox;

public class MainActivity extends AppCompatActivity {
    CheckBox checkBox;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        checkBox=(CheckBox)findViewById(R.id.checkBox);

        checkBox.setOncheckListener(new CheckBox.OnCheckListener() {
            @Override
            public void onCheck(CheckBox view, boolean check) {
                if(check){
                    Toast.makeText(MainActivity.this,"是否被选 "+check,Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this,"是否被选 "+check,Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
