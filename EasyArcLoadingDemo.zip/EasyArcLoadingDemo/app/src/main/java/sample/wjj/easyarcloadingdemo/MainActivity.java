package sample.wjj.easyarcloadingdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.camnter.easyarcloading.EasyArcLoading;

public class MainActivity extends AppCompatActivity {
    EasyArcLoading DialogDemo1, DialogDemo2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DialogDemo1 = (EasyArcLoading) findViewById(R.id.DialogDemo1);
        DialogDemo2 = (EasyArcLoading) findViewById(R.id.DialogDemo2);

        DialogDemo1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DialogDemo1.setVisibility(View.GONE);

            }

        });

        DialogDemo2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DialogDemo1.setVisibility(View.VISIBLE);
            }

        });

    }

}
