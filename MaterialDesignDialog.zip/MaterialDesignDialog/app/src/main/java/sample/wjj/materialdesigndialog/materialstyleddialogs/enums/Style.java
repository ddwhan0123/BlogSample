package sample.wjj.materialdesigndialog.materialstyleddialogs.enums;

public enum Style {
    STYLE_HEADER
}
