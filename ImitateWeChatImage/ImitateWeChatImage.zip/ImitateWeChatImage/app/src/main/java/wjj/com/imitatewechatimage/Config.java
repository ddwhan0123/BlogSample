package wjj.com.imitatewechatimage;

/**
 * Created by jiajiewang on 16/4/13.
 */
public class Config {
    public static final String IMAGE_URL = "http://ww2.sinaimg.cn/mw690/9e6995c9gw1f2uu70bzohj209q06g3yw.jpg";
}
