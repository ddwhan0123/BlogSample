package toolbardemo.wjj.toolbardemo;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ImageView imageView;
    Paint paint;
    Canvas canvas;
    Bitmap bitmap;
    Resources resources;
    int baseline;
    int height, width;
    ObjectAnimator objectAnimator1, objectAnimator2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        resources = getResources();

        toolbar.setTitle("大标题");
        toolbar.setSubtitle("小标题");
        toolbar.setNavigationIcon(R.mipmap.ic_launcher);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "退出了", Toast.LENGTH_SHORT).show();
                finish();
            }
        });

        //提示框部分
        imageView = (ImageView) findViewById(R.id.imageView);

        //画底板的画笔
        paint = new Paint();
        paint.setColor(resources.getColor(R.color.White));
        paint.setStrokeWidth(5);
        //抗鋸齒
        paint.setAntiAlias(true);
        //抖動處理
        paint.setDither(true);
        //屏幕的长宽
        width = this.getWindowManager().getDefaultDisplay().getWidth();
        height = this.getWindowManager().getDefaultDisplay().getHeight();
        bitmap = Bitmap.createBitmap(width, height / 15
                , Bitmap.Config.ARGB_8888);
        Log.d("--->width height", "  getWidth  " + this.getWindowManager().getDefaultDisplay().getWidth() +
                " getHeight()  " + this.getWindowManager().getDefaultDisplay().getHeight());
        canvas = new Canvas(bitmap);
        canvas.drawColor(resources.getColor(R.color.LightSkyBlue));

        //画字
        paint.setTextSize(50);
        Paint.FontMetricsInt fontMetrics = paint.getFontMetricsInt();
        baseline = (height / 15 - fontMetrics.bottom - fontMetrics.top) / 2;
        canvas.drawText("我就是要提示你的内容", 40, baseline, paint);
        imageView.setImageBitmap(bitmap);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Toast.makeText(this, "选中了action_settings", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.action_show) {
            showAnim();
            return true;
        } else if (id == R.id.action_hide) {
            hideAnim();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void hideAnim() {
        objectAnimator1 = ObjectAnimator.ofFloat(imageView, "translationY", 0.0f, -height / 15);

        objectAnimator2 = ObjectAnimator.ofFloat(imageView, "alpha", 0.8f, 0.0f);

        AnimatorSet animationSet = new AnimatorSet();//组合动画
        animationSet.play(objectAnimator1).with(objectAnimator2);

        animationSet.setDuration(500);

        animationSet.start();
        animationSet.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                Toast.makeText(MainActivity.this, "选中了action_hide", Toast.LENGTH_SHORT).show();
                imageView.clearAnimation();
                imageView.setVisibility(View.INVISIBLE);
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });
    }

    private void showAnim() {
        imageView.setVisibility(View.VISIBLE);
        objectAnimator1 = ObjectAnimator.ofFloat(imageView, "translationY", -height / 15,0.0f );

        objectAnimator2 = ObjectAnimator.ofFloat(imageView, "alpha", 0.0f, 1.0f);

        AnimatorSet animationSet = new AnimatorSet();//组合动画
        animationSet.play(objectAnimator1).with(objectAnimator2);

        animationSet.setDuration(500);

        animationSet.start();
    }

}
