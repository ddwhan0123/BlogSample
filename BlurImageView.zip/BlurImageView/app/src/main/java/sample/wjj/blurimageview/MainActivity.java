package sample.wjj.blurimageview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import sample.wjj.blurimageview.lib.BlurImageView;

public class MainActivity extends AppCompatActivity {
    private Button downLoad;
    private BlurImageView blurImageView;
    public static final String IMAGEURL = "https://cdn-images-1.medium.com/freeze/max/60/1*J0q0NNg1j9q3yV_ZVt-saw.jpeg?q=20";
    public static final String IMAGEURL1 = "https://cdn-images-1.medium.com/max/2000/1*J0q0NNg1j9q3yV_ZVt-saw.jpeg";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        downLoad = (Button) findViewById(R.id.downLoad);
        blurImageView = (BlurImageView) findViewById(R.id.image);
        downLoad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                blurImageView.setFullImageByUrl(IMAGEURL, IMAGEURL1);
            }
        });

    }
}