package sample.wjj.mvpdemo.Login;

/**
 * Created by jiajiewang on 16/3/29.
 */
public interface LoginLogic {
    void UserNameError();

    void PassWordError();

    void LoginSuccess();
}
