package sample.wjj.mvpdemo.Login;

/**
 * Created by jiajiewang on 16/3/29.
 */
public interface ClickInterface {
    void Login(String userName, String passWord);
}
