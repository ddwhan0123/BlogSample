package sample.wjj.mvpdemo.Login;

import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.apkfuns.logutils.LogUtils;
import com.jaeger.library.StatusBarUtil;
import com.rengwuxian.materialedittext.MaterialEditText;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import sample.wjj.mvpdemo.MainActivity;
import sample.wjj.mvpdemo.R;

public class LoginActivity extends AppCompatActivity implements LoginLogic {

    @Bind(R.id.fab)
    FloatingActionButton fab;
    @Bind(R.id.passWord)
    MaterialEditText passWord;
    @Bind(R.id.userName)
    MaterialEditText userName;
    ClickInterface clickInterface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);
        StatusBarUtil.setTransparent(this);
        clickInterface = new LoginControl(this);
    }

    @OnClick(R.id.fab)
    public void Login(View view) {
        LogUtils.d("--->fab Login");
        clickInterface.Login(userName.getText().toString().trim(), passWord.getText().toString().trim());
    }

    @Override
    public void UserNameError() {
        userName.setError("用户名有误");
    }

    @Override
    public void PassWordError() {
        passWord.setError("密码有误");
    }

    @Override
    public void LoginSuccess() {
        MainActivity.LogicSuccess(LoginActivity.this);
    }
}
