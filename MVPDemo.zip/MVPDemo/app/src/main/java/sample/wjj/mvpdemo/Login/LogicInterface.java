package sample.wjj.mvpdemo.Login;

/**
 * Created by jiajiewang on 16/3/29.
 */
public interface LogicInterface {

    interface OnLoginFabClick {

        void OnUserNameError();

        void OnPasswordError();

        void OnLoginSuccess();
    }

    void doLogin(String userNameStr, String passwordStr, OnLoginFabClick onLoginFabClick);
}
