package sample.wjj.mvpdemo.Login;

/**
 * Created by jiajiewang on 16/3/29.
 */
public class LoginInterfaceImp implements LogicInterface {


    @Override
    public void doLogin(String userNameStr, String passwordStr, OnLoginFabClick onLoginFabClick) {
        boolean flag = true;
        if (userNameStr.length() < 1 || userNameStr == null) {
            onLoginFabClick.OnUserNameError();
            flag = false;
        }
        if (passwordStr.length() < 1 || passwordStr == null) {
            onLoginFabClick.OnPasswordError();
            flag = false;
        }
        if (flag) {
            onLoginFabClick.OnLoginSuccess();
        }
    }


}
