package sample.wjj.mvpdemo.Login;

/**
 * Created by jiajiewang on 16/3/29.
 */
public class LoginControl implements LoginInterfaceImp.OnLoginFabClick, ClickInterface {

    LoginLogic loginLogic;
    LogicInterface logicInterface;

    public LoginControl(LoginLogic loginLogic) {
        this.loginLogic = loginLogic;
        this.logicInterface = new LoginInterfaceImp();
    }

    @Override
    public void OnUserNameError() {
        loginLogic.UserNameError();
    }

    @Override
    public void OnPasswordError() {
        loginLogic.PassWordError();
    }

    @Override
    public void OnLoginSuccess() {
        loginLogic.LoginSuccess();
    }

    @Override
    public void Login(String userName, String passWord) {
        logicInterface.doLogin(userName, passWord, this);
    }
}
