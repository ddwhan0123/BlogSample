package sample.wjj.materialdesignprogress;

import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import sample.wjj.materialdesignprogress.views.ProgressBarDeterminate;

public class MainActivity extends AppCompatActivity {
    ProgressBarDeterminate progressBarD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        progressBarD=(ProgressBarDeterminate)findViewById(R.id.progressBarD);

    }

    @Override
    protected void onResume() {
        super.onResume();
        progressTimer.start();
    }

    Handler handler = new Handler(new Handler.Callback() {
        int progress = 0;
        @Override
        public boolean handleMessage(Message msg) {
            progressBarD.setProgress(progress++);
            return false;
        }
    });

    Thread progressTimer = new Thread(new Runnable() {

        @Override
        public void run() {
            for(int i = 0; i <= 100; i++){
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                handler.sendMessage(new Message());
            }
        }
    });
}
